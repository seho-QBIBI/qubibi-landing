import QubibiLanding from './QubibiLanding';

function App() {
  return <QubibiLanding />;
}

export default App;
